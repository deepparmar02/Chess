#include "player.h"

Player::Player(Board &board) : board{board} {}

Player::~Player() {}